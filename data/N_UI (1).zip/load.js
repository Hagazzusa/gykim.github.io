function loadReadFile(file) {
	clear_cnvs();
	type_idx = 0;
	
	/* dTree 초기화 */
	var dtree = document.getElementById("dtreeDiv");
	if(dtree.hasChildNodes())
		dtree.removeChild(dtree.childNodes[0]);
	
	/* 테이블 초기화 */
	var my_tbody = document.getElementById('Show_Sentence');
    while(my_tbody.rows.length > 0)
		my_tbody.deleteRow( my_tbody.rows.length-1 ); // 하단부터 삭제
	
	function setup_reader(file, i, flag){ 
			var name = file.name;
			var reader = new FileReader();

			reader.onload = function(e) {
				var load_txt = e.target.result;
				if(load_txt[0] != "[")
					load_txt = "[" + load_txt;
				
				if(load_txt[load_txt.length-1] != "]")
					load_txt = load_txt + "]";
				
				load_txt = load_txt.replace(/] }\r\n\r\n{"text"/g, '] },\r\n\r\n{"text"');
				load_txt = load_txt.replace(/] }\n\n{"text"/g, '] },\n\n{"text"');
				load_txt = load_txt.replace(/] }\r\n\r\n{"text"/g, '] },\n\n{"text"');
				load_txt = load_txt.replace(/] }\n\n{"text"/g, '] },\r\n\r\n{"text"');
				
				var doc = JSON.parse(load_txt);
				TreeView(doc);
			};
			
			reader.onerror = function(evt) {
				alert(evt.target.error.code);
			};
			
			reader.onabort = function(e) {
				console.log("abort!!");
			};
			
			encoding = "utf-8";
			reader.readAsText(file, encoding);
	};

	if (file.length > 0) {
		Prev_file = file[0];
		setup_reader(file[0], 0, 0);
	} else 	{
		setup_reader(Prev_file, 0, 1);
	}
}