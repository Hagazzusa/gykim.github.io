function TreeView(doc) {

	function trigger(doc) {
		d = new dTree('d');
		var dtree_div = document.getElementById("dtreeDiv");
		var tree_idx = 1, prt_idx = 0;
		//console.log(d);
		
		if (dtree_div.hasChildNodes()) {
			this.removeElement(dtree_div);
		}

		if (d.aNodes.length > 0)
			console.log(d.aNodes.length);

		d.add(0, -1, 'Relation');
		
		console.log(doc);
		var check_arr;
		var re_idx;

		for (var i = 0; i < doc.length; i++) {
			add_row(doc[i], i);
			d.add(tree_idx, 0, "Sen_" + i);
			prt_idx = tree_idx;
			tree_idx++;
			
			console.log(i);
			check_arr = [];
			re_idx = [];
			for (var j = 0; j < doc[i].sentence[0].relation.length; j++) {
				var curr_re = doc[i].sentence[0].relation[j];
				var idx = check_arr.indexOf(curr_re.type);
				
				if(idx == -1) {
					check_arr.push(curr_re.type);
					idx = check_arr.indexOf(curr_re.type);
					d.add(tree_idx, prt_idx, curr_re.type);
					re_idx[idx] = tree_idx;
					tree_idx++;
					
					this_type[type_idx] = curr_re.type;
					d.add(tree_idx, re_idx[idx], "All", "dtree_click("+i+", "+j+", Doc, 'all', this, "+type_idx+");");
					tree_idx++;
					type_idx++;
				}
				Doc = doc;
				d.add(tree_idx, re_idx[idx], curr_re.arg1_text + "  →  " + curr_re.arg2_text, "dtree_click("+i+", "+j+", Doc, 'one', this, "+idx+");");
				tree_idx++;
			}
		}

		dtree_div.innerHTML = d;
	};


	/* delete newPid */
	function removeElement(element) {	
		var parent = element;
		
		parent.removeChild(document.getElementById("dtreeDivCh"));
	};

	trigger(doc);
	
	
};

var dtree_click = function(i, j, doc, checker, obj, idx) {
	clear_cnvs();
	
	for (var l = 0; l < Before_span.length; l++) {
		Before_span[l].setAttribute("style", "background-color", "false");
	}
	Before_span = [];
	
	Before_span.push(obj);
	obj.setAttribute("style", "background-color:aquamarine;");
	
	// 한 항목 확인
	if(checker == 'one') {
		
		var curr_rel = doc[i].sentence[0].relation[j];
		
		var canvas = document.getElementById("show_canvas");
		
		if (canvas.getContext) {
			var ctx = canvas.getContext('2d');
			var x1, y1, tx1, ty1, esx1, esy1, eex1, eey1;
			var x2, y2, tx2, ty2, esx2, esy2, eex2, eey2;
			var x3, y3, tx3, ty3;
			
			var x_size1;
			var x_size2;
			var x_size3;
			
			var text_len1 = curr_rel.arg1_text.length;
			var text_len2 = curr_rel.type.length;
			var text_len3 = curr_rel.arg2_text.length;
			
			var rect_fill, text_fill, stroke_fill;
			
			x_size1 = 19*text_len1;
			x_size2 = 19*text_len2;
			x_size3 = 19*text_len3;
			
			x2 = 450;	y2 = 50;
			tx2 = x2 + (x_size2 / 2);	ty2 = 75;
			esx2 = x2+(x_size2);	esy2 = 70;
			eex2 = esx2 + 100;	eey2 = esy2;
			
			x1 = 350 - x_size1;	y1 = 50;
			tx1 = x1 + (x_size1 / 2);	ty1 = 75;
			esx1 = x1+(x_size1);	esy1 = 70;
			eex1 = esx2 - 100;	eey1 = esy1;
			
			x3 = eex2;	y3 = y2;
			tx3 = x3 + (x_size3 / 2);	ty3 = 75;

			rect_fill = fill_color(curr_rel.type);
			//stroke_fill = stroke_color(curr_rel.type)
			text_fill = "black";
			
			//arg1_text 노드
			ctx.fillStyle = rect_fill;
			ctx.strokeRect(x1, y1, x_size1, 40);
			ctx.fillRect(x1+1, y1+1, x_size1-2, 38);
			ctx.font = '12pt  Calibri';
			ctx.textAlign = "center";
			ctx.fillStyle = text_fill;
			ctx.fillText(curr_rel.arg1_text, tx1, ty1);
			
			ctx.beginPath();
			ctx.moveTo(esx1, esy1);
			ctx.lineTo(eex1, eey1);
			ctx.stroke();
			
			//type 노드
			ctx.fillStyle = rect_fill;
			ctx.strokeRect(x2, y2, x_size2, 40);
			ctx.fillRect(x2+1, y2+1, x_size2-2, 38);
			ctx.font = '12pt  Calibri';
			ctx.textAlign = "center";
			ctx.fillStyle = text_fill;
			ctx.fillText(curr_rel.type, tx2, ty2);
			
			ctx.beginPath();
			ctx.moveTo(esx2, esy2);
			ctx.lineTo(eex2, eey2);
			ctx.stroke();
			
			//arg2_text 노드
			ctx.fillStyle = rect_fill;
			ctx.strokeRect(x3, y3, x_size3, 40);
			ctx.fillRect(x3+1, y3+1, x_size3-2, 38);
			ctx.font = '12pt  Calibri';
			ctx.textAlign = "center";
			ctx.fillStyle = text_fill;
			ctx.fillText(curr_rel.arg2_text, tx3, ty3);
		}
	}
	else {
		var curr_rel = doc[i].sentence[0].relation;
		var rel_len = curr_rel.length;
		
		var canvas = document.getElementById("show_canvas");
		
		if (canvas.getContext) {
			var ctx = canvas.getContext('2d');
			var x1, y1, tx1, ty1, esx1, esy1, eex1, eey1;
			var x2, y2, tx2, ty2, esx2, esy2, eex2, eey2;
			var x3, y3, tx3, ty3;
			
			var x_size1;
			var x_size2;
			var x_size3;
			
			var text_len1;//curr_rel.arg1_text.length;
			var text_len2;//curr_rel.type.length;
			var text_len3;//curr_rel.arg2_text.length;
			
			var rect_fill, text_fill, stroke_fill;
			
			console.log(this_type[idx]);
			var size_k = 0; 
			for(var k=0; k<rel_len; k++) {
				if(curr_rel[k].type==this_type[idx]){
					text_len1 = curr_rel[k].arg1_text.length;
					text_len2 = curr_rel[k].type.length;
					text_len3 = curr_rel[k].arg2_text.length;
					
					x_size1 = 19*text_len1;
					x_size2 = 19*text_len2;
					x_size3 = 19*text_len3;
					
					x2 = 450;	y2 = 50 + (70*size_k);
					tx2 = x2 + (x_size2 / 2);	ty2 = 75+ (70*size_k);
					esx2 = x2+(x_size2);	esy2 = 70+ (70*size_k);
					eex2 = esx2 + 100;	eey2 = esy2;
					
					x1 = 350 - x_size1;	y1 = 50+ (70*size_k);
					tx1 = x1 + (x_size1 / 2);	ty1 = 75+ (70*size_k);
					esx1 = x1+(x_size1);	esy1 = 70+ (70*size_k);
					eex1 = esx2 - 100;	eey1 = esy1;
					
					x3 = eex2;	y3 = y2;
					tx3 = x3 + (x_size3 / 2);	ty3 = 75+ (70*size_k);

					rect_fill = fill_color(curr_rel[k].type);
					//stroke_fill = stroke_color(curr_rel[k].type)
					text_fill = "black";
					
					//arg1_text 노드
					ctx.fillStyle = rect_fill;
					ctx.strokeStyle = stroke_fill;
					ctx.strokeRect(x1, y1, x_size1, 40);
					ctx.fillRect(x1+1, y1+1, x_size1-2, 38);
					ctx.font = '12pt  Calibri';
					ctx.textAlign = "center";
					ctx.fillStyle = text_fill;
					ctx.fillText(curr_rel[k].arg1_text, tx1, ty1);
					
					ctx.beginPath();
					ctx.moveTo(esx1, esy1);
					ctx.lineTo(eex1, eey1);
					ctx.stroke();
					
					//type 노드
					ctx.fillStyle = rect_fill;
					ctx.strokeRect(x2, y2, x_size2, 40);
					ctx.fillRect(x2+1, y2+1, x_size2-2, 38);
					ctx.font = '12pt  Calibri';
					ctx.textAlign = "center";
					ctx.fillStyle = text_fill;
					ctx.fillText(curr_rel[k].type, tx2, ty2);
					
					ctx.beginPath();
					ctx.moveTo(esx2, esy2);
					ctx.lineTo(eex2, eey2);
					ctx.stroke();
					
					//arg2_text 노드
					ctx.fillStyle = rect_fill;
					ctx.strokeRect(x3, y3, x_size3, 40);
					ctx.fillRect(x3+1, y3+1, x_size3-2, 38);
					ctx.font = '12pt  Calibri';
					ctx.textAlign = "center";
					ctx.fillStyle = text_fill;
					ctx.fillText(curr_rel[k].arg2_text, tx3, ty3);
					
					size_k++;
				}
			}
		}
	}
}

function add_row(doc, i) {
	var sen_table = document.getElementById("Show_Sentence");
	var row = sen_table.insertRow( sen_table.rows.length ); // 하단에 추가
	var cell1 = row.insertCell(0);
	var cell2 = row.insertCell(1);
		
	cell1.innerHTML = 'Sen_' + i;
	cell2.innerHTML = doc.text;
	
}

function clear_cnvs() {
	var canvas = document.getElementById("show_canvas");
	
	var ctx2 = canvas.getContext('2d');
	// 픽셀 정리
	ctx2.clearRect(0, 0, canvas.width, canvas.height);
	// 컨텍스트 리셋
	ctx2.beginPath();
}

function fill_color(re_type) {
	if(re_type == "has_person") {
		return "#82F9B7";
	}
	else if(re_type == "is_person_of"){
		return "#BEF5BE";
	}
	
	else if(re_type == "has_position") {
		return "#00D7FF";
	}
	else if(re_type == "is_position_of"){
		return "#32F1FF";
	}
	
	else if(re_type == "located") {
		return "#FFD0A1";
	}
	else if(re_type == "is_location_of"){
		return "#FFDBC1";
	}
	
	else if(re_type == "contain") {
		return "#90AFFF";
	}
	else if(re_type == "is_part_of"){
		return "#BECDFF";
	}
	
	else if(re_type == "has_age") {
		return "#14A0A0";
	}
	else if(re_type == "is_age_of"){
		return "#32BEBE";
	}
	
	else if(re_type == "has_school") {
		return "#FF88A7";
	}
	else if(re_type == "is_school_of"){
		return "#FFB6C1";
	}
	
	else if(re_type == "has_phone_number") {
		return "#FFD232";
	}
	else if(re_type == "is_phone_number_of"){
		return "#FFE650";
	}
	
	else if(re_type == "has_email") {
		return "#FF9100";
	}
	else if(re_type == "is_email_of"){
		return "#FFB900";
	}
	
	else if(re_type == "has_site") {
		return "#FF82C8";
	}
	else if(re_type == "is_site_of"){
		return "#FFA2D6";
	}
	
	else if(re_type == "has_id") {
		return "#FF6666";
	}
	else if(re_type == "is_id_of"){
		return "#FF9999";
	}
	
	else if(re_type == "equal") {
		return "#32AAFF";
	}
	else{
		return "#C0C0C0";
	}
	
}

function stroke_color(re_type) {
	if(re_type == "has_person") {
		return "#3DFF92";
	}
	else if(re_type == "is_person_of"){
		return "#AAEBAA";
	}
}