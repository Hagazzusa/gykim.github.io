#! /usr/bin/env python
# -*- coding: UTF-8 -*-
# vi:ts=4:tw=78:shiftwidth=4
# vim600:fdm=marker

import sys, math, cgi, string

def main():
    print "Content-type: text/html"
    print
    sys.stderr = sys.stdout

    form = cgi.FieldStorage()   # Replace with other classes to test those

    # decoding
    value = form['query']
    query = cgi.escape(value.value)

    # query
    word = query.split()
    for w in word:
        print w
    
    

if __name__ == "__main__":
    #_test()
    main()

